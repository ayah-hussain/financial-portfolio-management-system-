"""
Django Views for the PortfolioVantage Application.

These views handle:
- User registration and login (JWT-based)
- Portfolio creation, deletion, value calculation, and performance history
- Adding/removing assets from a portfolio
- Changing user passwords and updating user profiles
- Viewing available assets
- Retrieving news articles and user interactions (sentiment, comments)

All authenticating views use the @token_required decorator, which ensures a valid JWT is provided.
"""

import json
from datetime import datetime, timedelta
from decimal import Decimal
from functools import wraps

import jwt
from django.conf import settings
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import connection, transaction
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

# Retrieve JWT configurations from Django settings
JWT_SECRET = getattr(settings, 'JWT_SECRET_KEY', 'your-secret-key')
JWT_ALGORITHM = getattr(settings, 'JWT_ALGORITHM', 'HS256')

# ------------------------------------------------------------------------------
# Swagger/OpenAPI schemas and responses
# ------------------------------------------------------------------------------

register_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['username', 'password', 'email'],
    properties={
        'username': openapi.Schema(type=openapi.TYPE_STRING, description='Unique username for the new user'),
        'password': openapi.Schema(type=openapi.TYPE_STRING, description='Password for the account'),
        'email': openapi.Schema(type=openapi.TYPE_STRING, description='Unique email address'),
    }
)

login_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['username', 'password'],
    properties={
        'username': openapi.Schema(type=openapi.TYPE_STRING, description='The username of the account'),
        'password': openapi.Schema(type=openapi.TYPE_STRING, description='The password for the account'),
    }
)

register_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'message': openapi.Schema(type=openapi.TYPE_STRING),
        'user_id': openapi.Schema(type=openapi.TYPE_INTEGER),
    }
)

login_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'token': openapi.Schema(type=openapi.TYPE_STRING, description='JWT authentication token'),
    }
)

portfolio_create_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['portfolio_name'],
    properties={
        'portfolio_name': openapi.Schema(type=openapi.TYPE_STRING, description='Name for the new portfolio'),
    }
)

portfolio_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'message': openapi.Schema(type=openapi.TYPE_STRING),
        'portfolio_id': openapi.Schema(type=openapi.TYPE_INTEGER),
    }
)

portfolio_list_response = openapi.Schema(
    type=openapi.TYPE_ARRAY,
    items=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'name': openapi.Schema(type=openapi.TYPE_STRING),
            'total_value': openapi.Schema(type=openapi.TYPE_NUMBER, format='decimal'),
        }
    )
)

portfolio_assets_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['ticker', 'quantity', 'purchase_price'],
    properties={
        'ticker': openapi.Schema(type=openapi.TYPE_STRING, description='Asset ticker symbol'),
        'quantity': openapi.Schema(type=openapi.TYPE_NUMBER, description='Quantity to add/update'),
        'purchase_price': openapi.Schema(type=openapi.TYPE_NUMBER, description='Purchase price per unit'),
    }
)

portfolio_assets_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'assets': openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(
                type=openapi.TYPE_OBJECT,
                properties={
                    'ticker': openapi.Schema(type=openapi.TYPE_STRING),
                    'quantity': openapi.Schema(type=openapi.TYPE_NUMBER),
                    'average_price': openapi.Schema(type=openapi.TYPE_NUMBER),
                    'current_price': openapi.Schema(type=openapi.TYPE_NUMBER),
                    'current_value': openapi.Schema(type=openapi.TYPE_NUMBER),
                }
            )
        )
    }
)

user_profile_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'username': openapi.Schema(type=openapi.TYPE_STRING, description='New username'),
        'email': openapi.Schema(type=openapi.TYPE_STRING, description='New email address'),
    }
)

user_profile_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'message': openapi.Schema(type=openapi.TYPE_STRING),
        'user': openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'username': openapi.Schema(type=openapi.TYPE_STRING),
                'email': openapi.Schema(type=openapi.TYPE_STRING),
            }
        )
    }
)

portfolio_performance_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'performance_data': openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(
                type=openapi.TYPE_OBJECT,
                properties={
                    'date': openapi.Schema(type=openapi.TYPE_STRING, format='date'),
                    'value': openapi.Schema(type=openapi.TYPE_NUMBER),
                }
            )
        )
    }
)

news_interaction_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['sentiment'],
    properties={
        'sentiment': openapi.Schema(
            type=openapi.TYPE_STRING,
            description='User sentiment on the news',
            enum=['Ultra-Bullish', 'Positive', 'Neutral', 'Negative', 'Ultra-Bearish']
        ),
        'comment': openapi.Schema(type=openapi.TYPE_STRING, description='Optional comment on the news'),
    }
)

news_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        'news': openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(
                type=openapi.TYPE_OBJECT,
                properties={
                    'id': openapi.Schema(type=openapi.TYPE_INTEGER),
                    'category': openapi.Schema(type=openapi.TYPE_STRING),
                    'title': openapi.Schema(type=openapi.TYPE_STRING),
                    'content': openapi.Schema(type=openapi.TYPE_STRING),
                    'source': openapi.Schema(type=openapi.TYPE_STRING),
                    'author': openapi.Schema(type=openapi.TYPE_STRING),
                    'publishedat': openapi.Schema(type=openapi.TYPE_STRING, format='date-time'),
                    'interaction_count': openapi.Schema(type=openapi.TYPE_INTEGER),
                    'average_sentiment': openapi.Schema(type=openapi.TYPE_NUMBER),
                    'tickers': openapi.Schema(
                        type=openapi.TYPE_ARRAY,
                        items=openapi.Schema(type=openapi.TYPE_STRING)
                    ),
                }
            )
        )
    }
)

change_password_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['current_password', 'new_password'],
    properties={
        'current_password': openapi.Schema(type=openapi.TYPE_STRING, description='Current password'),
        'new_password': openapi.Schema(type=openapi.TYPE_STRING, description='New password'),
    }
)

# ------------------------------------------------------------------------------
# Authentication Decorator
# ------------------------------------------------------------------------------

def token_required(f):
    """
    Decorator that checks for a valid JWT in 'Authorization: Bearer <token>' header.
    - On success, attaches request.user_id
    - On failure, returns 401
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        request = args[0]
        token = request.headers.get('Authorization')

        if not token:
            return JsonResponse({'message': 'Token is missing'}, status=401)

        if not token.startswith('Bearer '):
            return JsonResponse({'message': 'Invalid token format'}, status=401)

        token = token.split(' ')[1]

        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            user_id = payload.get('user_id')

            # Ensure user exists
            with connection.cursor() as cursor:
                cursor.execute("SELECT userid FROM users WHERE userid = %s", [user_id])
                if not cursor.fetchone():
                    return JsonResponse({'message': 'Invalid token - user not found'}, status=401)

            request.user_id = user_id

        except jwt.ExpiredSignatureError:
            return JsonResponse({'message': 'Token has expired'}, status=401)
        except jwt.InvalidTokenError:
            return JsonResponse({'message': 'Invalid token'}, status=401)
        except Exception:
            return JsonResponse({'message': 'Error validating token'}, status=401)

        return f(*args, **kwargs)

    return decorated

# ------------------------------------------------------------------------------
# User Registration & Authentication
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='post',
    request_body=register_schema,
    responses={
        200: register_response,
        400: 'Bad Request - Missing fields or duplicate username/email',
        405: 'Method not allowed'
    },
    operation_description='Register a new user with username, password, and email.'
)
@api_view(['POST'])
@csrf_exempt
def register_user(request):
    """
    Register a new user with username, hashed password, and a unique email address.
    Returns a JSON response with user_id.
    """
    data = json.loads(request.body)
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')

    if not all([username, password, email]):
        return JsonResponse({'message': 'Missing required fields'}, status=400)

    try:
        validate_password(password)
    except ValidationError as e:
        return JsonResponse({'message': 'Invalid password', 'errors': e.messages}, status=400)

    hashed_password = make_password(password)
    with connection.cursor() as cursor:
        try:
            cursor.execute("""
                INSERT INTO users (username, password, email, createdat)
                VALUES (%s, %s, %s, CURRENT_TIMESTAMP)
                RETURNING userid;
            """, [username, hashed_password, email])
            user_id = cursor.fetchone()[0]
            return JsonResponse({'message': 'User created successfully', 'user_id': user_id})
        except Exception:
            return JsonResponse({'message': 'Username or email already exists'}, status=400)


@swagger_auto_schema(
    method='post',
    request_body=login_schema,
    responses={
        200: login_response,
        401: 'Unauthorized - Invalid credentials',
        405: 'Method not allowed'
    },
    operation_description='Authenticate a user by username & password and return a JWT token.'
)
@api_view(['POST'])
@csrf_exempt
def login(request):
    """
    Authenticate user with username & password.
    Returns a JWT token valid for 1 day.
    """
    data = json.loads(request.body)
    username = data.get('username')
    password = data.get('password')

    with connection.cursor() as cursor:
        cursor.execute("SELECT userid, password FROM users WHERE username = %s", [username])
        user = cursor.fetchone()

        if user and check_password(password, user[1]):
            token = jwt.encode({
                'user_id': user[0],
                'exp': datetime.utcnow() + timedelta(days=1)
            }, JWT_SECRET, algorithm=JWT_ALGORITHM)
            return JsonResponse({'token': token})

        return JsonResponse({'message': 'Invalid credentials'}, status=401)

# ------------------------------------------------------------------------------
# Portfolio Creation, Listing, and Deletion
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    methods=['get'],
    responses={
        200: portfolio_list_response,
        401: 'Unauthorized - Invalid or missing token'
    },
    operation_description='List all portfolios owned by the authenticated user with their current values.'
)
@swagger_auto_schema(
    methods=['post'],
    request_body=portfolio_create_schema,
    responses={
        200: portfolio_response,
        400: 'Bad Request - Missing or invalid portfolio name',
        401: 'Unauthorized - Invalid or missing token',
        500: 'Internal Server Error'
    },
    operation_description='Create a new portfolio for the authenticated user.'
)
@api_view(['GET', 'POST'])
@token_required
@csrf_exempt
def portfolio_list_create(request):
    """
    GET - Retrieve all user portfolios and their current total values.
    POST - Create a new portfolio for the user with an initial snapshot of 0.
    """
    user_id = getattr(request, 'user_id', None)

    if request.method == 'GET':
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH latest_prices AS (
                    SELECT DISTINCT ON (assetid) assetid, price
                    FROM pricehistory
                    ORDER BY assetid, timestamp DESC
                ),
                portfolio_values AS (
                    SELECT 
                        p.portfolioid,
                        COALESCE(SUM(pa.quantity * lp.price), 0) AS total_value
                    FROM portfolios p
                    LEFT JOIN portfolioassets pa ON p.portfolioid = pa.portfolioid
                    LEFT JOIN latest_prices lp ON pa.assetid = lp.assetid
                    WHERE p.userid = %s
                    GROUP BY p.portfolioid
                )
                SELECT 
                    p.portfolioid,
                    p.portfolioname,
                    COALESCE(pv.total_value, 0) AS total_value,
                    p.createdat
                FROM portfolios p
                LEFT JOIN portfolio_values pv ON p.portfolioid = pv.portfolioid
                WHERE p.userid = %s
                ORDER BY p.createdat DESC;
            """, [user_id, user_id])
            columns = [col[0] for col in cursor.description]
            portfolios = []

            for row in cursor.fetchall():
                portfolio = dict(zip(columns, row))
                portfolio['total_value'] = float(portfolio['total_value'])
                # Convert datetime to ISO format if needed
                if isinstance(portfolio['createdat'], datetime):
                    portfolio['createdat'] = portfolio['createdat'].isoformat()
                portfolios.append({
                    'id': portfolio['portfolioid'],
                    'name': portfolio['portfolioname'],
                    'total_value': portfolio['total_value'],
                    'created_at': portfolio['createdat']
                })
        return JsonResponse(portfolios, safe=False)

    elif request.method == 'POST':
        data = json.loads(request.body)
        portfolio_name = data.get('portfolio_name')
        if not portfolio_name:
            return JsonResponse({'message': 'Missing portfolio_name field'}, status=400)

        if len(portfolio_name) > 100:
            return JsonResponse({'message': 'Portfolio name too long'}, status=400)

        with connection.cursor() as cursor:
            try:
                # Ensure no duplicate names
                cursor.execute("""
                    SELECT COUNT(1) FROM portfolios
                    WHERE userid = %s AND portfolioname = %s
                """, [user_id, portfolio_name])
                if cursor.fetchone()[0] > 0:
                    return JsonResponse({'message': 'A portfolio with this name already exists'}, status=400)

                # Create the portfolio
                cursor.execute("""
                    INSERT INTO portfolios (userid, portfolioname, createdat)
                    VALUES (%s, %s, CURRENT_TIMESTAMP)
                    RETURNING portfolioid;
                """, [user_id, portfolio_name])
                portfolio_id = cursor.fetchone()[0]

                # Insert an initial snapshot with 0 total value
                cursor.execute("""
                    INSERT INTO portfoliosnapshots (portfolioid, timestamp, totalvalue)
                    VALUES (%s, CURRENT_TIMESTAMP, 0);
                """, [portfolio_id])
                return JsonResponse({'message': 'Portfolio created successfully', 'portfolio_id': portfolio_id})

            except Exception as e:
                return JsonResponse({'message': f'Error creating portfolio: {str(e)}'}, status=500)


@swagger_auto_schema(
    method='delete',
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'message': openapi.Schema(type=openapi.TYPE_STRING)}
        )),
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no access',
        405: 'Method not allowed'
    },
    operation_description='Delete a specific portfolio.'
)
@api_view(['DELETE'])
@token_required
@csrf_exempt
def delete_portfolio(request, portfolio_id):
    """
    Delete an existing portfolio owned by the authenticated user.
    """
    user_id = getattr(request, 'user_id', None)

    with connection.cursor() as cursor:
        # Check ownership
        cursor.execute("""
            SELECT COUNT(1)
            FROM portfolios
            WHERE portfolioid = %s AND userid = %s
        """, [portfolio_id, user_id])
        if cursor.fetchone()[0] == 0:
            return JsonResponse({'message': 'Portfolio not found or no permission'}, status=403)

        # Delete portfolio
        cursor.execute("DELETE FROM portfolios WHERE portfolioid = %s AND userid = %s", [portfolio_id, user_id])

    return JsonResponse({'message': 'Portfolio deleted successfully'})


# ------------------------------------------------------------------------------
# Portfolio Value and Performance
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='get',
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER)
    ],
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'total_value': openapi.Schema(type=openapi.TYPE_NUMBER)}
        )),
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no permission'
    },
    operation_description='Retrieve the current total value of a portfolio.'
)
@api_view(['GET'])
@token_required
def get_portfolio_value(request, portfolio_id):
    """
    Returns the current total value of the specified user portfolio.
    """
    user_id = getattr(request, 'user_id', None)
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT COALESCE(SUM(pa.quantity * COALESCE(ph.price, 0)), 0) AS total_value
            FROM portfolios p
            LEFT JOIN portfolioassets pa ON p.portfolioid = pa.portfolioid
            LEFT JOIN (
                SELECT DISTINCT ON (assetid) assetid, price
                FROM pricehistory
                ORDER BY assetid, timestamp DESC
            ) ph ON pa.assetid = ph.assetid
            WHERE p.portfolioid = %s AND p.userid = %s;
        """, [portfolio_id, user_id])
        total_value = cursor.fetchone()[0]

    return JsonResponse({'total_value': float(total_value or 0)})


@swagger_auto_schema(
    method='get',
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: portfolio_performance_response,
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no permission'
    },
    operation_description='Get daily portfolio performance snapshots.'
)
@api_view(['GET'])
@token_required
def get_portfolio_performance(request, portfolio_id):
    """
    Returns daily performance data for a portfolio (from snapshots or computed on-the-fly).
    """
    user_id = getattr(request, 'user_id', None)
    with connection.cursor() as cursor:
        # Check ownership
        cursor.execute("""
            SELECT createdat 
            FROM portfolios 
            WHERE portfolioid = %s AND userid = %s
        """, [portfolio_id, user_id])
        portfolio_data = cursor.fetchone()
        if not portfolio_data:
            return JsonResponse({'message': 'Portfolio not found or no permission'}, status=403)

        creation_date = portfolio_data[0]

        # Attempt to fetch from snapshots
        cursor.execute("""
            SELECT DATE(timestamp) AS date, totalvalue AS value
            FROM portfoliosnapshots ps
            JOIN portfolios p ON p.portfolioid = ps.portfolioid
            WHERE ps.portfolioid = %s AND p.userid = %s
            GROUP BY DATE(timestamp), totalvalue
            ORDER BY date
        """, [portfolio_id, user_id])
        performance_data = [
            {'date': row[0].strftime('%Y-%m-%d'), 'value': float(row[1])}
            for row in cursor.fetchall()
        ]

        # If no snapshot data, compute from price history
        if not performance_data:
            cursor.execute("""
                WITH daily_prices AS (
                    SELECT DISTINCT ON (assetid, DATE(timestamp))
                           assetid,
                           DATE(timestamp) AS date,
                           FIRST_VALUE(price) OVER (
                               PARTITION BY assetid, DATE(timestamp)
                               ORDER BY timestamp DESC
                           ) AS price
                    FROM pricehistory
                    WHERE timestamp >= %s
                    ORDER BY assetid, DATE(timestamp), timestamp DESC
                )
                SELECT 
                    dp.date,
                    SUM(pa.quantity * dp.price) AS total_value
                FROM portfolios p
                JOIN portfolioassets pa ON p.portfolioid = pa.portfolioid
                JOIN daily_prices dp ON pa.assetid = dp.assetid
                WHERE p.portfolioid = %s AND p.userid = %s
                GROUP BY dp.date
                ORDER BY dp.date
            """, [creation_date, portfolio_id, user_id])
            rows = cursor.fetchall()
            performance_data = [
                {'date': row[0].strftime('%Y-%m-%d'), 'value': float(row[1])}
                for row in rows
            ]

            # Create a latest snapshot to store the computed value
            if performance_data:
                latest_value = performance_data[-1]['value']
                cursor.execute("""
                    INSERT INTO portfoliosnapshots (portfolioid, timestamp, totalvalue)
                    SELECT %s, CURRENT_TIMESTAMP, %s
                    WHERE EXISTS (
                        SELECT 1 FROM portfolios WHERE portfolioid = %s AND userid = %s
                    );
                """, [portfolio_id, latest_value, portfolio_id, user_id])

    return JsonResponse({'performance_data': performance_data})

# ------------------------------------------------------------------------------
# Portfolio Assets Management
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='get',
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: portfolio_assets_response,
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no permission'
    },
    operation_description='Get all assets in a portfolio with their current values.'
)
@swagger_auto_schema(
    method='post',
    request_body=portfolio_assets_schema,
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response('Success', portfolio_assets_response),
        400: 'Bad Request - Missing required fields',
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no permission',
        404: 'Not found - Asset not recognized',
    },
    operation_description='Add or update an asset within a portfolio.'
)
@api_view(['GET', 'POST'])
@token_required
@csrf_exempt
def get_portfolio_assets(request, portfolio_id):
    """
    GET - Retrieve a list of assets in the specified portfolio.
    POST - Add or update a specific asset in the portfolio with quantity and purchase price.
    """
    user_id = getattr(request, 'user_id', None)

    if request.method == 'GET':
        with connection.cursor() as cursor:
            # Ensure the user owns the portfolio
            cursor.execute("""
                SELECT COUNT(1) 
                FROM portfolios 
                WHERE portfolioid = %s AND userid = %s
            """, [portfolio_id, user_id])
            if cursor.fetchone()[0] == 0:
                return JsonResponse({'message': 'Portfolio not found or no permission'}, status=403)

            # Retrieve assets
            cursor.execute("""
                SELECT 
                    a.ticker,
                    pa.quantity,
                    pa.averagepurchaseprice AS average_price,
                    COALESCE(ph.price, 0) AS current_price,
                    COALESCE(ph.price * pa.quantity, 0) AS current_value
                FROM portfolios p
                JOIN portfolioassets pa ON p.portfolioid = pa.portfolioid
                JOIN assets a ON pa.assetid = a.assetid
                LEFT JOIN (
                    SELECT DISTINCT ON (assetid) assetid, price
                    FROM pricehistory
                    ORDER BY assetid, timestamp DESC
                ) ph ON a.assetid = ph.assetid
                WHERE pa.portfolioid = %s AND p.userid = %s;
            """, [portfolio_id, user_id])

            columns = [col[0] for col in cursor.description]
            assets = [
                {
                    col: float(val) if isinstance(val, (Decimal, float)) else val
                    for col, val in zip(columns, row)
                }
                for row in cursor.fetchall()
            ]
            return JsonResponse({'assets': assets})

    elif request.method == 'POST':
        data = json.loads(request.body)
        ticker = data.get('ticker')
        quantity = data.get('quantity')
        purchase_price = data.get('purchase_price')

        if not all([ticker, quantity, purchase_price]) and quantity is not None:
            return JsonResponse({'message': 'Missing required fields'}, status=400)

        with connection.cursor() as cursor:
            # Check portfolio ownership
            cursor.execute("""
                SELECT COUNT(1) 
                FROM portfolios 
                WHERE portfolioid = %s AND userid = %s
            """, [portfolio_id, user_id])
            if cursor.fetchone()[0] == 0:
                return JsonResponse({'message': 'Portfolio not found or no permission'}, status=403)

            # Check if asset exists
            cursor.execute("SELECT assetid FROM assets WHERE ticker = %s", [ticker])
            asset_row = cursor.fetchone()
            if not asset_row:
                return JsonResponse({'message': 'Asset ticker not recognized'}, status=404)

            asset_id = asset_row[0]

            try:
                with transaction.atomic():
                    # Insert or update asset in portfolioassets
                    # averagepurchaseprice updated via weighted average or direct assignment?
                    # Simplify to direct update or custom logic
                    cursor.execute("""
                        SELECT quantity, averagepurchaseprice
                        FROM portfolioassets
                        WHERE portfolioid = %s AND assetid = %s
                    """, [portfolio_id, asset_id])
                    existing_asset = cursor.fetchone()

                    if existing_asset:
                        old_qty, old_price = float(existing_asset[0]), float(existing_asset[1])
                        new_qty = old_qty + quantity
                        # Weighted average calculation
                        weighted_price = (old_qty * old_price + quantity * purchase_price) / new_qty
                        cursor.execute("""
                            UPDATE portfolioassets
                            SET quantity = %s, averagepurchaseprice = %s
                            WHERE portfolioid = %s AND assetid = %s
                        """, [new_qty, weighted_price, portfolio_id, asset_id])
                    else:
                        cursor.execute("""
                            INSERT INTO portfolioassets (portfolioid, assetid, ticker, quantity, averagepurchaseprice)
                            VALUES (%s, %s, %s, %s, %s)
                        """, [portfolio_id, asset_id, ticker, quantity, purchase_price])

                    # Update portfolio snapshot
                    cursor.execute("""
                        WITH current_prices AS (
                            SELECT ph1.assetid, ph1.price AS current_price
                            FROM pricehistory ph1
                            INNER JOIN (
                                SELECT assetid, MAX(timestamp) AS max_timestamp
                                FROM pricehistory
                                GROUP BY assetid
                            ) ph2 ON ph1.assetid = ph2.assetid AND ph1.timestamp = ph2.max_timestamp
                        )
                        SELECT COALESCE(SUM(pa.quantity * cp.current_price), 0) AS total_value
                        FROM portfolioassets pa
                        JOIN portfolios p ON pa.portfolioid = p.portfolioid
                        JOIN current_prices cp ON pa.assetid = cp.assetid
                        WHERE p.portfolioid = %s AND p.userid = %s;
                    """, [portfolio_id, user_id])
                    total_value = cursor.fetchone()[0]

                    cursor.execute("""
                        INSERT INTO portfoliosnapshots (portfolioid, timestamp, totalvalue)
                        VALUES (%s, CURRENT_TIMESTAMP, %s)
                        ON CONFLICT (portfolioid, timestamp) DO UPDATE
                        SET totalvalue = EXCLUDED.totalvalue;
                    """, [portfolio_id, total_value])

                # Return updated asset list
                cursor.execute("""
                    SELECT 
                        a.ticker,
                        pa.quantity,
                        pa.averagepurchaseprice AS average_price,
                        COALESCE(ph.price, 0) AS current_price,
                        COALESCE(ph.price * pa.quantity, 0) AS current_value
                    FROM portfolioassets pa
                    JOIN assets a ON pa.assetid = a.assetid
                    LEFT JOIN (
                        SELECT DISTINCT ON (assetid) assetid, price
                        FROM pricehistory
                        ORDER BY assetid, timestamp DESC
                    ) ph ON a.assetid = ph.assetid
                    WHERE pa.portfolioid = %s;
                """, [portfolio_id])
                columns = [col[0] for col in cursor.description]
                assets = [
                    {
                        col: float(val) if isinstance(val, (Decimal, float)) else val
                        for col, val in zip(columns, row)
                    }
                    for row in cursor.fetchall()
                ]
                return JsonResponse({'assets': assets})

            except Exception as e:
                return JsonResponse({'message': f'Error updating asset: {str(e)}'}, status=500)

# ------------------------------------------------------------------------------
# Removing an Asset from Portfolio
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='delete',
    manual_parameters=[
        openapi.Parameter('portfolio_id', openapi.IN_PATH, description='Portfolio ID', type=openapi.TYPE_INTEGER),
        openapi.Parameter('ticker', openapi.IN_PATH, description='Asset ticker symbol', type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'message': openapi.Schema(type=openapi.TYPE_STRING)}
        )),
        401: 'Unauthorized - Invalid or missing token',
        403: 'Forbidden - Portfolio not found or no permission',
        404: 'Not Found - Asset not found in portfolio',
        405: 'Method Not Allowed'
    },
    operation_description='Remove a specific asset from a portfolio owned by the authenticated user.'
)
@api_view(['DELETE'])
@token_required
@csrf_exempt
def delete_asset_from_portfolio(request, portfolio_id, ticker):
    """
    DELETE endpoint for removing an asset from the user's portfolio.
    Updates the portfolio snapshot after removal.
    """
    user_id = getattr(request, 'user_id', None)

    with connection.cursor() as cursor:
        # Check portfolio ownership
        cursor.execute("""
            SELECT COUNT(1)
            FROM portfolios 
            WHERE portfolioid = %s AND userid = %s
        """, [portfolio_id, user_id])
        if cursor.fetchone()[0] == 0:
            return JsonResponse({'message': "Portfolio not found or no permission"}, status=403)

        # Delete the asset record
        cursor.execute("""
            DELETE FROM portfolioassets pa
            USING portfolios p
            WHERE pa.portfolioid = p.portfolioid
              AND p.portfolioid = %s 
              AND p.userid = %s
              AND pa.ticker = %s
            RETURNING pa.assetid;
        """, [portfolio_id, user_id, ticker])

        deleted_asset = cursor.fetchone()
        if not deleted_asset:
            return JsonResponse({'message': 'Asset not found in portfolio'}, status=404)

        # Update snapshot
        cursor.execute("""
            WITH current_prices AS (
                SELECT ph1.assetid, ph1.price AS current_price
                FROM pricehistory ph1
                INNER JOIN (
                    SELECT assetid, MAX(timestamp) AS max_timestamp
                    FROM pricehistory
                    GROUP BY assetid
                ) ph2 ON ph1.assetid = ph2.assetid AND ph1.timestamp = ph2.max_timestamp
            )
            SELECT COALESCE(SUM(pa.quantity * cp.current_price), 0) 
            FROM portfolioassets pa
            JOIN portfolios p ON pa.portfolioid = p.portfolioid
            JOIN current_prices cp ON pa.assetid = cp.assetid
            WHERE p.portfolioid = %s AND p.userid = %s;
        """, [portfolio_id, user_id])
        total_value = cursor.fetchone()[0]

        cursor.execute("""
            INSERT INTO portfoliosnapshots (portfolioid, timestamp, totalvalue)
            VALUES (%s, CURRENT_TIMESTAMP, %s)
            ON CONFLICT (portfolioid, timestamp) DO UPDATE
            SET totalvalue = EXCLUDED.totalvalue;
        """, [portfolio_id, total_value])

    return JsonResponse({'message': 'Asset removed successfully'})

# ------------------------------------------------------------------------------
# User Profile Update & Password Change
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='put',
    request_body=user_profile_schema,
    responses={
        200: user_profile_response,
        400: 'Bad Request - No fields to update or duplicates',
        401: 'Unauthorized - Invalid or missing token',
        404: 'Not Found - User not found',
        405: 'Method Not Allowed',
        500: 'Internal Server Error'
    },
    operation_description='Update the authenticated user\'s profile (username/email).'
)
@api_view(['PUT'])
@token_required
@csrf_exempt
def update_user_profile(request):
    """
    Update authenticated user's username and/or email if available.
    Returns the updated profile on success.
    """
    user_id = getattr(request, 'user_id', None)
    data = json.loads(request.body)

    username = data.get('username')
    email = data.get('email')
    if not any([username, email]):
        return JsonResponse({'message': 'No fields to update'}, status=400)

    update_fields = []
    params = []

    if username:
        update_fields.append("username = %s")
        params.append(username)
    if email:
        update_fields.append("email = %s")
        params.append(email)

    params.append(user_id)

    with connection.cursor() as cursor:
        try:
            # Check for duplicates
            if username:
                cursor.execute("SELECT COUNT(1) FROM users WHERE username = %s AND userid != %s", [username, user_id])
                if cursor.fetchone()[0] > 0:
                    return JsonResponse({'message': 'Username already exists'}, status=400)

            if email:
                cursor.execute("SELECT COUNT(1) FROM users WHERE email = %s AND userid != %s", [email, user_id])
                if cursor.fetchone()[0] > 0:
                    return JsonResponse({'message': 'Email already exists'}, status=400)

            # Perform the update
            query = f"""
                UPDATE users
                SET {", ".join(update_fields)}
                WHERE userid = %s
                RETURNING username, email;
            """
            cursor.execute(query, params)
            updated_user = cursor.fetchone()
            if not updated_user:
                return JsonResponse({'message': 'User not found'}, status=404)

            return JsonResponse({
                'message': 'Profile updated successfully',
                'user': {
                    'username': updated_user[0],
                    'email': updated_user[1]
                }
            })

        except Exception as e:
            return JsonResponse({'message': f'Error updating profile: {str(e)}'}, status=500)


@swagger_auto_schema(
    method='post',
    request_body=change_password_schema,
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'message': openapi.Schema(type=openapi.TYPE_STRING)}
        )),
        400: 'Bad Request - Invalid current password',
        401: 'Unauthorized - Invalid or missing token'
    },
    operation_description='Change the authenticated user\'s password.'
)
@api_view(['POST'])
@token_required
@csrf_exempt
def change_password(request):
    """
    Change the password of the currently authenticated user.
    Validates current password before setting the new one.
    """
    data = json.loads(request.body)
    current_password = data.get('current_password')
    new_password = data.get('new_password')
    user_id = getattr(request, 'user_id', None)

    if not all([current_password, new_password]):
        return JsonResponse({'message': 'Missing required fields'}, status=400)

    with connection.cursor() as cursor:
        cursor.execute("SELECT password FROM users WHERE userid = %s", [user_id])
        user = cursor.fetchone()
        if not user or not check_password(current_password, user[0]):
            return JsonResponse({'message': 'Current password is incorrect'}, status=400)

        # Update password
        hashed_password = make_password(new_password)
        cursor.execute("UPDATE users SET password = %s WHERE userid = %s", [hashed_password, user_id])

    return JsonResponse({'message': 'Password updated successfully'})

# ------------------------------------------------------------------------------
# Assets Endpoint
# ------------------------------------------------------------------------------

@api_view(['GET'])
@token_required
def get_available_assets(request):
    """
    Retrieve a list of all available assets in the system.
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT ticker, assetname, assettype, source FROM assets ORDER BY ticker;")
        columns = [col[0] for col in cursor.description]
        assets = [dict(zip(columns, row)) for row in cursor.fetchall()]
    return JsonResponse({'assets': assets})

# ------------------------------------------------------------------------------
# News and Interactions
# ------------------------------------------------------------------------------

@swagger_auto_schema(
    method='get',
    responses={
        200: news_response,
        401: 'Unauthorized - Invalid or missing token'
    },
    operation_description='Retrieve all news articles sorted by latest publication date.'
)
@api_view(['GET'])
@token_required
def get_news(request):
    """
    Returns a list of news articles with aggregated user interaction counts and average sentiment.
    """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT 
                n.newsid AS id,
                n.category,
                n.title,
                n.content,
                n.source,
                n.author,
                n.publishedat,
                COUNT(DISTINCT ni.userid) AS interaction_count,
                COALESCE(AVG(CASE
                    WHEN ni.sentiment = 'Ultra-Bullish' THEN 5
                    WHEN ni.sentiment = 'Positive' THEN 4
                    WHEN ni.sentiment = 'Neutral' THEN 3
                    WHEN ni.sentiment = 'Negative' THEN 2
                    WHEN ni.sentiment = 'Ultra-Bearish' THEN 1
                END), 3) AS average_sentiment,
                array_agg(DISTINCT nat.ticker) AS tickers
            FROM news n
            LEFT JOIN newsinteractions ni ON n.newsid = ni.newsid
            LEFT JOIN newsassettags nat ON n.newsid = nat.newsid
            GROUP BY n.newsid
            ORDER BY n.publishedat DESC;
        """)
        columns = [col[0] for col in cursor.description]
        news_items = []
        for row in cursor.fetchall():
            item = dict(zip(columns, row))
            if isinstance(item['publishedat'], datetime):
                item['publishedat'] = item['publishedat'].isoformat()
            item['average_sentiment'] = float(item['average_sentiment'])
            item['tickers'] = [t for t in item['tickers'] if t] if item['tickers'] else []
            news_items.append(item)
    return JsonResponse({'news': news_items})


@swagger_auto_schema(
    method='post',
    request_body=news_interaction_schema,
    manual_parameters=[
        openapi.Parameter('news_id', openapi.IN_PATH, description='News article ID', type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'message': openapi.Schema(type=openapi.TYPE_STRING)}
        )),
        400: 'Bad Request - Missing or invalid sentiment',
        401: 'Unauthorized - Invalid or missing token',
        404: 'Not Found - News article does not exist'
    },
    operation_description='Record or update user sentiment/comment for a news article.'
)
@api_view(['POST'])
@token_required
@csrf_exempt
def interact_with_news(request, news_id):
    """
    Insert or update a user's sentiment and optional comment for a specified news article.
    """
    user_id = getattr(request, 'user_id', None)
    data = json.loads(request.body)
    sentiment = data.get('sentiment')
    comment = data.get('comment', '')

    valid_sentiments = ['Ultra-Bullish', 'Positive', 'Neutral', 'Negative', 'Ultra-Bearish']
    if not sentiment or sentiment not in valid_sentiments:
        return JsonResponse({'message': 'Invalid sentiment value'}, status=400)

    with connection.cursor() as cursor:
        # Check if news exists
        cursor.execute("SELECT newsid FROM news WHERE newsid = %s", [news_id])
        if not cursor.fetchone():
            return JsonResponse({'message': 'News article not found'}, status=404)

        try:
            with transaction.atomic():
                cursor.execute("""
                    INSERT INTO newsinteractions (newsid, userid, sentiment, comment, createdat)
                    VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP)
                    ON CONFLICT (newsid, userid) DO UPDATE
                    SET sentiment = EXCLUDED.sentiment,
                        comment = EXCLUDED.comment,
                        createdat = CURRENT_TIMESTAMP
                    RETURNING newsid;
                """, [news_id, user_id, sentiment, comment])
                if not cursor.fetchone():
                    return JsonResponse({'message': 'Failed to record interaction'}, status=500)

            return JsonResponse({'message': 'Interaction recorded successfully'})

        except Exception as e:
            return JsonResponse({'message': f'Failed to record interaction: {str(e)}'}, status=500)

@swagger_auto_schema(
    method='get',
    responses={
        200: news_response,
        404: 'Not Found - News article does not exist'
    },
    operation_description='Retrieve all comments on selected news article, if there is one.'
)
@api_view(['GET'])
@token_required
def get_news_comments(request, news_id):
    """
    Retrieve comments (and sentiment) for a particular news article.
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM news WHERE newsid = %s;", [news_id])
        if cursor.fetchone()[0] == 0:
            return JsonResponse({'message': 'News article not found'}, status=404)

        cursor.execute("""
            SELECT
                ni.userid,
                u.username,
                ni.sentiment,
                ni.comment,
                ni.createdat
            FROM newsinteractions ni
            JOIN users u ON ni.userid = u.userid
            WHERE ni.newsid = %s
            ORDER BY ni.createdat DESC;
        """, [news_id])
        columns = [col[0] for col in cursor.description]
        comments = []
        for row in cursor.fetchall():
            entry = dict(zip(columns, row))
            if isinstance(entry['createdat'], datetime):
                entry['createdat'] = entry['createdat'].isoformat()
            comments.append(entry)
    return JsonResponse({'comments': comments})

@swagger_auto_schema(
    method='post',
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'start_date': openapi.Schema(type=openapi.TYPE_STRING, format='date'),
            'asset_allocation': openapi.Schema(
                type=openapi.TYPE_OBJECT,
                additional_properties=openapi.Schema(type=openapi.TYPE_NUMBER)
            ),
            'monthly_budget': openapi.Schema(type=openapi.TYPE_NUMBER),
        },
        required=['start_date', 'asset_allocation', 'monthly_budget']
    ),
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'simulation_data': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'date': openapi.Schema(type=openapi.TYPE_STRING),
                        'total_value': openapi.Schema(type=openapi.TYPE_NUMBER),
                        'total_invested': openapi.Schema(type=openapi.TYPE_NUMBER),
                        'assets': openapi.Schema(type=openapi.TYPE_ARRAY, items=openapi.Schema(
                            type=openapi.TYPE_OBJECT,
                            properties={
                                'ticker': openapi.Schema(type=openapi.TYPE_STRING),
                                'shares': openapi.Schema(type=openapi.TYPE_NUMBER),
                                'value': openapi.Schema(type=openapi.TYPE_NUMBER),
                            }
                        ))
                    }
                ))
            }
        ))
    }
)
@api_view(['POST'])
@token_required
def simulate_investment(request):
    """
    Simulates an investment strategy based on start date, asset allocation, and monthly budget.
    """
    try:
        data = json.loads(request.body)
        start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        asset_allocation = data['asset_allocation']
        monthly_budget = float(data['monthly_budget'])

        # Validate allocation percentages sum to 100 and are positive
        total_percentage = 0
        for ticker, percentage in asset_allocation.items():
            if percentage <= 0:
                return JsonResponse({'error': f'Percentage for {ticker} must be positive'}, status=400)
            total_percentage += percentage

        if not (99.5 <= total_percentage <= 100.5):  # Allow for small floating-point errors
            return JsonResponse({'error': 'Asset allocation percentages must sum to 100'}, status=400)

        # Validate assets exist
        with connection.cursor() as cursor:
            placeholders = ','.join(['%s'] * len(asset_allocation))
            cursor.execute(f"""
                SELECT ticker 
                FROM assets 
                WHERE ticker IN ({placeholders})
            """, list(asset_allocation.keys()))
            
            found_assets = {row[0] for row in cursor.fetchall()}
            if len(found_assets) != len(asset_allocation):
                invalid_assets = set(asset_allocation.keys()) - found_assets
                return JsonResponse({'error': f'Invalid assets: {", ".join(invalid_assets)}'}, status=400)

            # Get historical prices for simulation
            cursor.execute("""
                WITH RECURSIVE dates AS (
                    SELECT %s::timestamp AS date
                    UNION ALL
                    SELECT (date + interval '1 day')::timestamp
                    FROM dates
                    WHERE date < CURRENT_TIMESTAMP
                ),
                daily_prices AS (
                    SELECT 
                        a.ticker,
                        d.date::date as date,
                        COALESCE(
                            (
                                SELECT price 
                                FROM pricehistory ph
                                WHERE ph.assetid = a.assetid 
                                AND DATE(ph.timestamp) <= d.date::date
                                ORDER BY ph.timestamp DESC 
                                LIMIT 1
                            ),
                            0
                        ) as price
                    FROM dates d
                    CROSS JOIN (
                        SELECT a.assetid, a.ticker
                        FROM assets a
                        WHERE a.ticker = ANY(%s)
                    ) a
                )
                SELECT ticker, date, price
                FROM daily_prices
                ORDER BY date, ticker;
            """, [start_date, list(asset_allocation.keys())])

            # Process results
            simulation_data = []
            current_shares = {ticker: 0 for ticker in asset_allocation}
            total_invested = 0
            current_date = start_date
            prices_by_date = {}

            # Group prices by date
            for row in cursor.fetchall():
                ticker, date, price = row
                if date not in prices_by_date:
                    prices_by_date[date] = {}
                prices_by_date[date][ticker] = float(price)  # Convert Decimal to float

            if not prices_by_date:
                return JsonResponse({'error': 'No price data available for the selected date range'}, status=400)

            # Simulate monthly investments
            for date, prices in prices_by_date.items():
                # Make monthly investment
                if date.day == start_date.day:
                    total_invested += monthly_budget
                    # Calculate shares to buy for each asset
                    for ticker, percentage in asset_allocation.items():
                        if prices[ticker] > 0:  # Avoid division by zero
                            investment_amount = (monthly_budget * percentage / 100)
                            new_shares = investment_amount / prices[ticker]
                            current_shares[ticker] += new_shares

                # Calculate current values
                assets_data = []
                total_value = 0
                for ticker, shares in current_shares.items():
                    value = shares * prices[ticker]
                    total_value += value
                    assets_data.append({
                        'ticker': ticker,
                        'shares': float(shares),  # Convert Decimal to float
                        'value': float(value)     # Convert Decimal to float
                    })

                simulation_data.append({
                    'date': date.strftime('%Y-%m-%d'),
                    'total_value': float(total_value),       # Convert Decimal to float
                    'total_invested': float(total_invested), # Convert Decimal to float
                    'assets': assets_data
                })

        return JsonResponse({'simulation_data': simulation_data})

    except (KeyError, ValueError, json.JSONDecodeError) as e:
        print(f"Simulation error (validation): {str(e)}")  # Add logging
        return JsonResponse({'error': str(e)}, status=400)
    except Exception as e:
        print(f"Simulation error (unexpected): {str(e)}")  # Add logging
        return JsonResponse({'error': 'Internal server error: ' + str(e)}, status=500)

@swagger_auto_schema(
    method='delete',
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'confirmation': openapi.Schema(
                type=openapi.TYPE_STRING,
                description='Confirmation string to delete account ("Yes, I approve that I want to delete my user account.")'
            )
        },
        required=['confirmation']
    ),
    responses={
        200: openapi.Response('Success', openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={'message': openapi.Schema(type=openapi.TYPE_STRING)}
        )),
        400: 'Bad Request - Invalid confirmation or session issue',
        401: 'Unauthorized - Invalid or missing token',
        500: 'Internal Server Error'
    },
    operation_description='Delete the authenticated user account after confirmation.'
)
@api_view(['DELETE'])
@token_required
@csrf_exempt
def delete_account(request):
    """
    Delete the authenticated user's account.
    Requires a confirmation string and removes the user from the database.
    """
    user_id = getattr(request, 'user_id', None)
    data = json.loads(request.body)
    confirmation = data.get('confirmation')

    # Check confirmation string
    expected_confirmation = "Yes, I approve that I want to delete my user account."
    if confirmation != expected_confirmation:
        return JsonResponse({'message': 'Invalid confirmation string'}, status=400)

    with connection.cursor() as cursor:
        try:
            # Delete the user account
            cursor.execute("DELETE FROM users WHERE userid = %s", [user_id])

            # Check if the user was deleted
            if cursor.rowcount == 0:
                return JsonResponse({'message': 'User not found'}, status=400)

            # Invalidate the JWT token by returning a 401 response or prompting re-login
            response = JsonResponse({'message': 'Account deleted successfully'})
            response.delete_cookie('Authorization')  # Remove the token cookie if stored in cookies
            return response
        except Exception as e:
            return JsonResponse({'message': f'Error deleting account: {str(e)}'}, status=500)
