"""
URL routing for the PortfolioVantage application.

Includes endpoints for:
- Portfolio management (CRUD)
- Portfolio assets management
- User account management (registration, login, change password, profile update)
- News and user interactions with news
"""

from django.urls import path
from .views import (
    portfolio_list_create,
    delete_portfolio,
    get_portfolio_value,
    get_portfolio_performance,
    get_portfolio_assets,
    delete_asset_from_portfolio,
    change_password,
    update_user_profile,
    register_user,
    login,
    get_available_assets,
    get_news,
    interact_with_news,
    get_news_comments,
    simulate_investment,
    delete_account
)

urlpatterns = [

    # Portfolio management
    path('portfolios/', portfolio_list_create, name='portfolio_list_create'),            # GET (list), POST (create)
    path('portfolios/<int:portfolio_id>/', delete_portfolio, name='delete_portfolio'),   # DELETE
    path('portfolios/<int:portfolio_id>/value/', get_portfolio_value, name='get_portfolio_value'),               # GET
    path('portfolios/<int:portfolio_id>/performance/', get_portfolio_performance, name='get_portfolio_performance'),  # GET

    # Portfolio assets management
    path('portfolios/<int:portfolio_id>/assets/', get_portfolio_assets, name='portfolio_assets'),                      # GET, POST
    path('portfolios/<int:portfolio_id>/assets/<str:ticker>/', delete_asset_from_portfolio, name='delete_asset_from_portfolio'),  # DELETE

    # User account management
    path('auth/change-password/', change_password, name='change_password'),  # POST
    path('auth/profile/', update_user_profile, name='update_user_profile'),  # PUT
    path('auth/register/', register_user, name='register_user'),             # POST
    path('auth/login/', login, name='login'),                               # POST

    # Assets
    path('assets/', get_available_assets, name='get_available_assets'),      # GET

    # News and interactions
    path('news/', get_news, name='get_news'),                                         # GET
    path('news/<int:news_id>/interact/', interact_with_news, name='interact_with_news'),  # POST
    path('news/<int:news_id>/comments/', get_news_comments, name='get_news_comments'),     # GET

    # Simulation
    path('simulate-investment/', simulate_investment, name='simulate_investment'),
    path('auth/delete-account/', delete_account, name='delete_account'),

]
